package com.tmuintentionalrelationships;

import java.net.URISyntaxException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.QuadCurve;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;

public class AdminPanel extends Application{
	public static void main(String[] args){
		launch();
	}
	public void start(Stage stage) throws InterruptedException, URISyntaxException {
		GridPane pane = new GridPane();
		stage.setTitle("Admin Panel");
		Scene scene = new Scene(pane, 1500, 800);
		scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
		
		try{
		      Class.forName("com.mysql.jdbc.Driver");

	          Connection myConn = null;

	          myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tmuir", "root", null);
	          Statement mySts = myConn.createStatement();
	          //SELECT COUNT(DATE(`DateJoined`)) FROM `userdata` GROUP BY `DateJoined` DESC LIMIT 5

	          ResultSet myRes = mySts.executeQuery("SELECT COUNT(`userID`) FROM `userData`");
	          	          	          
	          int last = 0;
	          while(myRes.next()){
		          	Text users = new Text();
	            	users = new Text(myRes.getString(1));
	            	System.out.println(myRes.getString(1));
	            	users.setId("fancytext");
	            	pane.add(users, 0, 0);
	          }
	          
	          myRes = mySts.executeQuery("SELECT SUM(`DateJoined`) FROM `userdata` ORDER BY `DateJoined` DESC LIMIT 5");
	          
	          int i =0;
	          myRes.next();
          	  last = Integer.parseInt(myRes.getString(1));
          	  
	          
	          while(myRes.next()){
	        	  	int test = Integer.parseInt(myRes.getString(1));
			        QuadCurve quadCurve = new QuadCurve(i*20, test, (i*20 + 10), test, (i*20 + 20), test);
			          
			        pane.add(quadCurve, i++, 0);
	            	System.out.println(myRes.getString(1));
	            	last = Integer.parseInt(myRes.getString(1));
	          }
	        }
	        catch(Exception ex){
	          System.out.println(ex);
	        }
		stage.setScene(scene);
		stage.show();
		
	}
}
